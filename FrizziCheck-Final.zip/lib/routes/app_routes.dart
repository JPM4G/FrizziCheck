import 'package:flutter/material.dart';
import '../core/app_export.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';
import '../presentation/create_account_page_screen/create_account_page_screen.dart';
import '../presentation/home_page_screen/home_page_screen.dart';
import '../presentation/login_page_screen/login_page_screen.dart';
import '../presentation/profile_page_container_screen/profile_page_container_screen.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class AppRoutes {
  static const String createAccountPageScreen = '/create_account_page_screen';

  static const String loginPageScreen = '/login_page_screen';

  static const String homePageScreen = '/home_page_screen';

  static const String profilePageContainerScreen =
      '/profile_page_container_screen';

  static const String profilePage = '/profile_page';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> routes = {
    createAccountPageScreen: (context) => CreateAccountPageScreen(),
    loginPageScreen: (context) => LoginPageScreen(),
    homePageScreen: (context) => HomePageScreen(),
    profilePageContainerScreen: (context) => ProfilePageContainerScreen(),
    appNavigationScreen: (context) => AppNavigationScreen(),
    initialRoute: (context) => LoginPageScreen()
  };
}
