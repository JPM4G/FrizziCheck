// ignore_for_file: must_be_immutable
class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

// Home Page images
  static String imgGroup38 = '$imagePath/img_group_38.png';

  static String imgNavHome = '$imagePath/img_nav_home.svg';

// Profile Page - Container images
  static String imgNavHomeOnprimarycontainer =
      '$imagePath/img_nav_home_onprimarycontainer.svg';

  static String imgNavProfileBlue600 =
      '$imagePath/img_nav_profile_blue_600.svg';

// Profile Page images
  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgWavyBuddiesAvatar = '$imagePath/img_wavy_buddies_avatar.png';

  static String imgGroup41 = '$imagePath/img_group_41.svg';

// Common images
  static String imgNavProfile = '$imagePath/img_nav_profile.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
