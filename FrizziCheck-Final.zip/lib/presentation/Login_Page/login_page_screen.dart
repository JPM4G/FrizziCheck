import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_text_form_field.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class LoginPageScreen extends StatelessWidget {
  LoginPageScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController userNameController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: SizedBox(
              height: SizeUtils.height,
              child: Form(
                key: _formKey,
                child: Container(
                  width: double.maxFinite,
                  padding: EdgeInsets.symmetric(
                    horizontal: 37.h,
                    vertical: 89.v,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        decoration: AppDecoration.outlineBlackF,
                        child: Text(
                          "FRIZZI",
                          style: theme.textTheme.displayMedium,
                        ),
                      ),
                      SizedBox(height: 61.v),
                      _buildUserName(context),
                      SizedBox(height: 12.v),
                      _buildPassword(context),
                      SizedBox(height: 8.v),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: EdgeInsets.only(left: 26.h),
                          child: Text(
                            "Forgot password?",
                            style: CustomTextStyles.bodyMediumGray100,
                          ),
                        ),
                      ),
                      SizedBox(height: 27.v),
                      _buildLogin(context),
                      SizedBox(height: 42.v),
                      Text(
                        "Don’t have a account?",
                        style: CustomTextStyles.bodyMediumGray100,
                      ),
                      SizedBox(height: 8.v),
                      _buildCreateAccount(context),
                      Spacer(),
                      SizedBox(height: 4.v),
                      RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "Frizzi ",
                              style: CustomTextStyles.bodyMediumGray500,
                            ),
                            TextSpan(
                              text: "©  2024",
                              style: theme.textTheme.bodyLarge,
                            )
                          ],
                        ),
                        textAlign: TextAlign.left,
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildUserName(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 26.h,
        right: 25.h,
      ),
      child: CustomTextFormField(
        controller: userNameController,
        hintText: "Username or email address",
        textInputType: TextInputType.emailAddress,
      ),
    );
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 25.h),
      child: CustomTextFormField(
        controller: passwordController,
        hintText: "Password",
        textInputAction: TextInputAction.done,
        textInputType: TextInputType.visiblePassword,
        obscureText: true,
      ),
    );
  }

  /// Section Widget
  Widget _buildLogin(BuildContext context) {
    return CustomElevatedButton(
      text: "Login",
      buttonStyle: CustomButtonStyles.fillBlueTL5,
      onPressed: () {
        onTapLogin(context);
      },
    );
  }

  /// Section Widget
  Widget _buildCreateAccount(BuildContext context) {
    return CustomElevatedButton(
      width: 140.h,
      text: "Create Account",
      buttonStyle: CustomButtonStyles.fillLime,
      buttonTextStyle: theme.textTheme.titleSmall!,
      onPressed: () {
        onTapCreateAccount(context);
      },
    );
  }

  /// Navigates to the homePageScreen when the action is triggered.
  onTapLogin(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.homePageScreen);
  }

  /// Navigates to the createAccountPageScreen when the action is triggered.
  onTapCreateAccount(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.createAccountPageScreen);
  }
}
