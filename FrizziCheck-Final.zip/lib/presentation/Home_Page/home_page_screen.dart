import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../profile_page/profile_page.dart';

// ignore_for_file: must_be_immutable
class HomePageScreen extends StatelessWidget {
  HomePageScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBody: true,
        extendBodyBehindAppBar: true,
        body: Container(
          width: SizeUtils.width,
          height: SizeUtils.height,
          decoration: BoxDecoration(
            color: theme.colorScheme.onPrimary,
            image: DecorationImage(
              image: AssetImage(
                ImageConstant.imgGroup38,
              ),
              fit: BoxFit.cover,
            ),
          ),
          child: Container(
            padding: EdgeInsets.symmetric(
              horizontal: 21.h,
              vertical: 20.v,
            ),
            child: Column(
              children: [
                SizedBox(height: 30.v),
                SizedBox(
                  width: 331.h,
                  child: Text(
                    "“Life is 10% what happens to you and 90% how you react to it”",
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style:
                        CustomTextStyles.headlineSmallStardosStencil.copyWith(
                      height: 1.28,
                    ),
                  ),
                ),
                Spacer(),
                CustomElevatedButton(
                  height: 48.v,
                  text: "TEST",
                  margin: EdgeInsets.only(
                    left: 25.h,
                    right: 33.h,
                  ),
                  buttonStyle: CustomButtonStyles.fillYellow,
                  buttonTextStyle: theme.textTheme.titleLarge!,
                  onPressed: () {
                    // Navigate to ProfilePage when the button is clicked
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ProfilePage(),
                      ),
                    );
                  },
                ),
                SizedBox(height: 16.v),
                Text(
                  " REACTION TIME TEST",
                  style: CustomTextStyles.bodyMediumGray100,
                )
              ],
            ),
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        if (type == BottomBarEnum.Profile) {
          // Navigate to ProfilePage when the profile button is tapped
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ProfilePage(),
            ),
          );
        } else {
          Navigator.pushNamed(
              navigatorKey.currentContext!, getCurrentRoute(type));
        }
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Profile:
        return AppRoutes.profilePage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.profilePage:
        return ProfilePage();
      default:
        return DefaultWidget();
    }
  }
}
