import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import '../../../core/app_export.dart'; // ignore: must_be_immutable

class ListoveralltimeItemWidget extends StatelessWidget {
  const ListoveralltimeItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Container(
        width: 303.h,
        padding: EdgeInsets.symmetric(
          horizontal: 6.h,
          vertical: 5.v,
        ),
        decoration: BoxDecoration(
          image: DecorationImage(
            image: fs.Svg(
              ImageConstant.imgGroup41,
            ),
            fit: BoxFit.cover,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(
                left: 11.h,
                top: 9.v,
                bottom: 34.v,
              ),
              child: Text(
                "Overall Time:",
                style: theme.textTheme.bodySmall,
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                top: 9.v,
                bottom: 34.v,
              ),
              child: Text(
                "Recommended Job:",
                style: CustomTextStyles.bodySmallSecondaryContainer,
              ),
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 46.v),
              child: Text(
                "10 min ago",
                style: CustomTextStyles.bodySmallBluegray40001,
              ),
            )
          ],
        ),
      ),
    );
  }
}
