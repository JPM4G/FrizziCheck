import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_outlined_button.dart';
import 'widgets/listoveralltime_item_widget.dart'; // ignore_for_file: must_be_immutable

class ProfilePage extends StatelessWidget {
  const ProfilePage({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 26.h,
            vertical: 13.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgWavyBuddiesAvatar,
                height: 100.adaptSize,
                width: 100.adaptSize,
                radius: BorderRadius.circular(
                  50.h,
                ),
                margin: EdgeInsets.only(left: 5.h),
              ),
              SizedBox(height: 11.v),
              _buildRowLabel(context),
              SizedBox(height: 4.v),
              Padding(
                padding: EdgeInsets.only(left: 4.h),
                child: Text(
                  "johncena_bingchilling@china.com",
                  style: CustomTextStyles.bodySmallBluegray400,
                ),
              ),
              SizedBox(height: 32.v),
              Padding(
                padding: EdgeInsets.only(left: 5.h),
                child: Text(
                  "Result History ",
                  style: theme.textTheme.headlineMedium,
                ),
              ),
              SizedBox(height: 15.v),
              _buildListOverallTime(context)
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 64.v,
      leadingWidth: 40.h,
      leading: Container(
        height: 24.adaptSize,
        width: 24.adaptSize,
        margin: EdgeInsets.only(
          left: 16.h,
          top: 15.v,
          bottom: 16.v,
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgArrowLeft,
              height: 24.adaptSize,
              width: 24.adaptSize,
              alignment: Alignment.center,
              onTap: () {
                onTapImgArrowleftone(context);
              },
            ),
            CustomImageView(
              imagePath: ImageConstant.imgArrowLeft,
              height: 24.adaptSize,
              width: 24.adaptSize,
              alignment: Alignment.center,
            )
          ],
        ),
      ),
      centerTitle: true,
      title: SizedBox(
        height: 31.v,
        width: 65.h,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Align(
              alignment: Alignment.center,
              child: Text(
                "Profile",
                style: theme.textTheme.headlineSmall,
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Text(
                "Profile",
                style: theme.textTheme.headlineSmall,
              ),
            )
          ],
        ),
      ),
      actions: [
        Container(
          height: 24.adaptSize,
          width: 24.adaptSize,
          margin: EdgeInsets.fromLTRB(16.h, 15.v, 16.h, 16.v),
          child: Stack(
            alignment: Alignment.center,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgNavProfile,
                height: 24.adaptSize,
                width: 24.adaptSize,
                alignment: Alignment.center,
              ),
              CustomImageView(
                imagePath: ImageConstant.imgNavProfile,
                height: 24.adaptSize,
                width: 24.adaptSize,
                alignment: Alignment.center,
              )
            ],
          ),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildRowLabel(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 4.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: EdgeInsets.only(
              top: 5.v,
              bottom: 1.v,
            ),
            child: Text(
              "Bing Chillin John Cena",
              style: CustomTextStyles.bodyLargeOnPrimaryContainer,
            ),
          ),
          CustomOutlinedButton(
            width: 100.h,
            text: "Log out",
            onPressed: () {
              onTapLogout(context);
            },
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildListOverallTime(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 10.h),
        child: ListView.separated(
          physics: NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          separatorBuilder: (context, index) {
            return SizedBox(
              height: 8.v,
            );
          },
          itemCount: 4,
          itemBuilder: (context, index) {
            return ListoveralltimeItemWidget();
          },
        ),
      ),
    );
  }

  /// Navigates back to the previous screen.
  onTapImgArrowleftone(BuildContext context) {
    Navigator.pop(context);
  }

  /// Navigates to the loginPageScreen when the action is triggered.
  onTapLogout(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.loginPageScreen);
  }
}
