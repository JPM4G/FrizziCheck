import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_text_form_field.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class CreateAccountPageScreen extends StatelessWidget {
  CreateAccountPageScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  TextEditingController confirmPasswordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: SingleChildScrollView(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: SizedBox(
            height: SizeUtils.height,
            child: Form(
              key: _formKey,
              child: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(
                  horizontal: 37.h,
                  vertical: 51.v,
                ),
                child: Column(
                  children: [
                    SizedBox(
                      width: 186.h,
                      child: Text(
                        "Create Account",
                        maxLines: null,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: CustomTextStyles.headlineSmallBold,
                      ),
                    ),
                    SizedBox(height: 39.v),
                    _buildEmail(context),
                    SizedBox(height: 12.v),
                    _buildPassword(context),
                    SizedBox(height: 12.v),
                    _buildConfirmPassword(context),
                    SizedBox(height: 37.v),
                    _buildSignUp(context),
                    SizedBox(height: 31.v),
                    Text(
                      "Already have an account?",
                      style: CustomTextStyles.bodyMediumGray100,
                    ),
                    SizedBox(height: 7.v),
                    _buildLogin(context),
                    Spacer(),
                    SizedBox(height: 42.v),
                    RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: "Frizzi ",
                            style: CustomTextStyles.bodyMediumGray500,
                          ),
                          TextSpan(
                            text: "©  2024",
                            style: theme.textTheme.bodyLarge,
                          )
                        ],
                      ),
                      textAlign: TextAlign.left,
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      centerTitle: true,
      title: AppbarTitle(
        text: "FRIZZI",
      ),
      styleType: Style.bgOutline,
    );
  }

  /// Section Widget
  Widget _buildEmail(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 26.h,
        right: 25.h,
      ),
      child: CustomTextFormField(
        controller: emailController,
        hintText: "Email address",
        textInputType: TextInputType.emailAddress,
      ),
    );
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 26.h,
        right: 25.h,
      ),
      child: CustomTextFormField(
        controller: passwordController,
        hintText: "Password",
        textInputType: TextInputType.visiblePassword,
        obscureText: true,
      ),
    );
  }

  /// Section Widget
  Widget _buildConfirmPassword(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 26.h,
        right: 25.h,
      ),
      child: CustomTextFormField(
        controller: confirmPasswordController,
        hintText: "Confirm Password",
        textInputAction: TextInputAction.done,
        textInputType: TextInputType.visiblePassword,
        obscureText: true,
      ),
    );
  }

  /// Section Widget
  Widget _buildSignUp(BuildContext context) {
    return CustomElevatedButton(
      text: "Sign up",
      onPressed: () {
        onTapSignUp(context);
      },
    );
  }

  /// Section Widget
  Widget _buildLogin(BuildContext context) {
    return CustomElevatedButton(
      width: 140.h,
      text: "Login",
      buttonStyle: CustomButtonStyles.fillBlue,
      buttonTextStyle: theme.textTheme.titleSmall!,
      onPressed: () {
        onTapLogin(context);
      },
    );
  }

  /// Navigates to the homePageScreen when the action is triggered.
  onTapSignUp(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.homePageScreen);
  }

  /// Navigates to the loginPageScreen when the action is triggered.
  onTapLogin(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.loginPageScreen);
  }
}
